package com.shopping.microservicse.customerserviceanitha;

import java.net.URI;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.cloud.netflix.hystrix.EnableHystrix;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
//import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@RestController
@EnableHystrix
@RefreshScope
public class CustomerController {

	@Autowired
	CustomerRepository customerRepository;
	
	@Autowired
	private RabbitTemplate template;
	
	@Autowired
	CustomerConfiguration customerConfiguration;
	
	private static final Logger logger = LoggerFactory.getLogger(CustomerController.class);
	
	@GetMapping("/customers")
		public List<Customer> getCustomerDetails() {
		    logger.info("inside customer service - in get mapping");
			List<Customer> customer = customerRepository.findAll();
			return customer;
			}
	@PostMapping("/customer")	
	public ResponseEntity<Object> createCustomer(@RequestBody Customer customer1) {
	   logger.info("inside customer service - in post mapping");
	   Customer savedCustomer = customerRepository.save(customer1);
		template.convertAndSend(customer1);
		URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}")
				.buildAndExpand(savedCustomer.getId()).toUri();
		
		return ResponseEntity.created(location).build();
	}
	
	@GetMapping("/customerdetails/fault-tolerance")
	@HystrixCommand(fallbackMethod="fallbackCustomerDetails")
	public Customer getCustomerDetailsFaultTolerance() {
		throw new RuntimeException("Some Issue");
	}	
	public Customer fallbackCustomerDetails() {
		//return new Customer(999L,"abc@mail.com","fff","lll");
		return new Customer(customerConfiguration.getDefaultId(),customerConfiguration.getDefaultEmailId(),customerConfiguration.getDefaultFirstName(),customerConfiguration.getDefaultLastName());
	}
}
