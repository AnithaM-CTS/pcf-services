insert into customer(Id,Email,First_Name,Last_Name) values (101,'ani@gmail.com','Ani','Muru');
insert into customer(Id,Email,First_Name,Last_Name) values (102,'moni@gmail.com','Moni','Muru');
