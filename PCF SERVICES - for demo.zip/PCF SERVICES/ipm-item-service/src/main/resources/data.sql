insert into item(item_id,item_name,item_description,item_price) values(100,'thermometer','health supplies',100.0);
insert into item(item_id,item_name,item_description,item_price) values(101,'kitkat','candy',15.0);
insert into item(item_id,item_name,item_description,item_price) values(102,'geometry box','stationary',50.0);
