package com.pcf.serviceregistry.consumer;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GreeterApplicationTests {

	@Test
	void contextLoads() {
	}

}
